$(document).ready(function() {
	
	/** MOBILE MENU **/
	
	$('#mobile-menu-icon').on("click",function() {
		if(!$(this).hasClass('open')){
			$(this).addClass('open');
			$('#mobile-menu').addClass('menu-open');
			$('.mobile-menu-overlay').show();
		}
		else{
			$(this).removeClass('open');
			$('#mobile-menu').removeClass('menu-open');
			$('.mobile-menu-overlay').hide();
		}	
	});
	
	
	/** MOBILE SUB MENU **/
	
	          var rwdMenu = $('.rwd-menu'),
                topMenu = $('.rwd-menu > li > a'),
                topSubMenu = $('.rwd-menu > li > ul > li > a'),
                parentLi = $('.rwd-menu > li'),
                parentLisubMenu = $('.rwd-menu > li > ul > li'),
                backBtn = $('.back-btn'),
                subMenubackBtn = $('.back-btn-submenu'),
                topHeader = $('#top-header');
 
                topMenu.on('click',function(e){
                                var thisTopMenu = $(this).parent(); // current $this
                                rwdMenu.addClass('rwd-menu-view');
                                parentLi.removeClass('open-submenu');
                                thisTopMenu.addClass('open-submenu');
                                topHeader.addClass('active');
                                if(parentLi.hasClass('open-submenu')){
                                                $('#back-btn').show();
                                }
                                else{
                                                $('#back-btn').hide();
                                }
                               
                });
               
                topSubMenu.on('click',function(e){
                                var thisTopMenu = $(this).parent();
                                parentLisubMenu.removeClass('open-submenu2');
                                thisTopMenu.addClass('open-submenu2');
                               
                                if(parentLisubMenu.hasClass('open-submenu2')){
                                                $('#back-btn').hide();
                                                $('#back-btn-submenu').show();
                                }
                                else{
                                                $('#back-btn-submenu').hide();
                                }
                               
                });
 
                backBtn.click(function(){
                                var thisBackBtn = $(this);
                                parentLi.removeClass('open-submenu');
                                rwdMenu.removeClass('rwd-menu-view');
                                $('#back-btn').hide();
                                topHeader.removeClass('active');
                });
               
                subMenubackBtn.click(function(){
                                var thisBackBtn = $(this);
                                parentLisubMenu.removeClass('open-submenu2');
                                $('#back-btn-submenu').hide();
                                $('#back-btn').show();
                });
	
	/** MOBILE MENU CLICK OUTSIDE CLOSE **/
	
	$("html").click(function(event) {
		if ($(event.target).closest('#menu-side, #mobile-menu').length === 0) {
			$('#mobile-menu-icon').removeClass('open');
			$('#mobile-menu').removeClass('menu-open');
			$('.mobile-menu-overlay').hide();
		}
	});

});
